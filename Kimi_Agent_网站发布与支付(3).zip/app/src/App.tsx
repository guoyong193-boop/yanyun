import { useState } from 'react';
import { Gamepad2, Shield, Sword, Flame, Check, QrCode, MessageCircle, Copy, CheckCircle2, CreditCard } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface ServiceItem {
  id: string;
  name: string;
  price: number;
  isHot?: boolean;
  isRecommended?: boolean;
}

interface ServiceCategory {
  id: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  bgGradient: string;
  items: ServiceItem[];
}

const serviceData: ServiceCategory[] = [
  {
    id: 'power-leveling',
    title: '开荒代练服务',
    subtitle: '势力值快速提升 · 专业配将',
    icon: <Sword className="w-6 h-6" />,
    bgGradient: 'from-pink-500 to-rose-500',
    items: [
      { id: 'pl1', name: '代肝1000势力值', price: 15 },
      { id: 'pl2', name: '2000势力值 + 3级城府配将', price: 40 },
      { id: 'pl3', name: '5000势力值 + 5级城府配将', price: 65 },
      { id: 'pl4', name: '9000势力值 + 7级城府3级兵营配将', price: 115 },
      { id: 'pl5', name: '10000势力值 + 7级城府10级兵营配将', price: 130 },
      { id: 'pl6', name: '12000势力值 + 8级城府10级兵营配将', price: 170 },
      { id: 'pl7', name: '15000势力值 + 8级城府10级兵营配将', price: 215 },
      { id: 'pl8', name: '18000势力值 + 8级城府10级兵营配将', price: 270 },
      { id: 'pl9', name: '20000势力值 + 8级城府13级兵营配将', price: 320 },
      { id: 'pl10', name: '20000势力值 + 8级城府15级兵营配将', price: 420 },
      { id: 'pl11', name: '30000势力值 + 8级城府20级兵营配将', price: 520 },
      { id: 'pl12', name: '极限开荒 5000-7000势力7本', price: 185, isHot: true },
      { id: 'pl13', name: '极限开荒 10000势力7本5兵营', price: 300, isHot: true },
      { id: 'pl14', name: '极限开荒 20000势力7本5兵营', price: 780, isHot: true },
    ],
  },
  {
    id: 'account-hosting',
    title: '账号托管服务',
    subtitle: '全天候控号 · 稳定在线',
    icon: <Shield className="w-6 h-6" />,
    bgGradient: 'from-blue-500 to-cyan-500',
    items: [
      { id: 'ah1', name: '日常控号 (每天8小时) - 1天', price: 27 },
      { id: 'ah2', name: '中级控号 (每天10小时) - 1天', price: 37 },
      { id: 'ah3', name: '强力控号 (每天14小时) - 2天', price: 47 },
      { id: 'ah4', name: '终极控号 (每天18小时) - 1天', price: 75 },
      { id: 'ah5', name: '夜晚控号 (22点-8点) - 1晚', price: 55 },
      { id: 'ah6', name: '日常控号 (每天8小时) - 3天', price: 95 },
      { id: 'ah7', name: '中级控号 (每天14小时) - 3天', price: 95 },
      { id: 'ah8', name: '终极控号 (每天18小时) - 3天', price: 125 },
      { id: 'ah9', name: '夜晚控号 (22点-8点) - 3晚', price: 155 },
      { id: 'ah10', name: '夜晚控号 (每天8小时) - 7天', price: 173 },
      { id: 'ah11', name: '中级控号 (每天10小时) - 7天', price: 225 },
      { id: 'ah12', name: '强力控号 (每天14小时) - 7天', price: 280 },
      { id: 'ah13', name: '终极控号 (每天18小时) - 7天', price: 430, isRecommended: true },
      { id: 'ah14', name: '夜晚控号 (22点-8点) - 7晚', price: 340 },
    ],
  },
];

// ==================== 修改联系方式在这里 ====================
// 修改下面的内容即可更新网站上的联系方式
const CONTACT_INFO = {
  wechat: 'YanYunStudio2024',  // 微信号
  qq: '2681369883',            // QQ号 ← 已更新
  phone: '138****8888',        // 手机号
};
// =========================================================

type PaymentMethod = 'wechat' | 'alipay';

function App() {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('wechat');
  const [copied, setCopied] = useState(false);

  const handleServiceClick = (service: ServiceItem) => {
    setSelectedService(service);
    setDialogOpen(true);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500">
      {/* Header */}
      <header className="pt-8 pb-6 px-4 text-center">
        <div className="flex items-center justify-center gap-3 mb-2">
          <Gamepad2 className="w-10 h-10 text-white" />
          <h1 className="text-3xl md:text-4xl font-bold text-white tracking-wide">
            烟云工作室
          </h1>
        </div>
        <p className="text-white/80 text-sm md:text-base">
          全网性价比 / 极速 / 效率 / 安全 / 靠谱
        </p>
      </header>

      {/* Main Content */}
      <main className="px-4 pb-8 max-w-md mx-auto space-y-6">
        {serviceData.map((category) => (
          <section
            key={category.id}
            className="bg-white rounded-2xl overflow-hidden shadow-2xl"
          >
            {/* Category Header */}
            <div className={`bg-gradient-to-r ${category.bgGradient} px-5 py-4`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
                  {category.icon}
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">{category.title}</h2>
                  <p className="text-white/80 text-xs">{category.subtitle}</p>
                </div>
              </div>
            </div>

            {/* Service Items */}
            <div className="p-4 space-y-2">
              {category.items.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleServiceClick(item)}
                  className="flex items-center justify-between py-3 px-3 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors group"
                >
                  <div className="flex items-center gap-2 flex-1 pr-3">
                    {item.isHot && (
                      <span className="flex items-center gap-1 text-rose-500 text-xs font-medium">
                        <Flame className="w-3 h-3" />
                        极限开荒
                      </span>
                    )}
                    <span className={`text-sm ${item.isHot ? 'text-rose-600 font-medium' : 'text-gray-700'}`}>
                      {item.name}
                    </span>
                    {item.isHot && (
                      <span className="px-1.5 py-0.5 bg-rose-500 text-white text-[10px] rounded font-medium">
                        HOT
                      </span>
                    )}
                    {item.isRecommended && (
                      <span className="px-1.5 py-0.5 bg-blue-500 text-white text-[10px] rounded font-medium">
                        推荐
                      </span>
                    )}
                  </div>
                  <button className="px-4 py-1.5 bg-gradient-to-r from-rose-500 to-red-500 text-white text-sm font-medium rounded-full shadow-lg shadow-rose-500/30 hover:shadow-rose-500/50 hover:scale-105 transition-all whitespace-nowrap">
                    ¥{item.price}
                  </button>
                </div>
              ))}
            </div>
          </section>
        ))}

        {/* Contact Section */}
        <section className="bg-white rounded-2xl overflow-hidden shadow-2xl">
          <div className="bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">联系我们</h2>
                <p className="text-white/80 text-xs">下单前请先咨询客服</p>
              </div>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-xl">
              <span className="text-gray-700 text-sm">微信号</span>
              <div className="flex items-center gap-2">
                <span className="font-medium text-gray-900">{CONTACT_INFO.wechat}</span>
                <button 
                  onClick={() => copyToClipboard(CONTACT_INFO.wechat)}
                  className="p-1.5 text-gray-500 hover:text-emerald-500 hover:bg-emerald-50 rounded-lg transition-colors"
                >
                  {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-xl">
              <span className="text-gray-700 text-sm">QQ号</span>
              <div className="flex items-center gap-2">
                <span className="font-medium text-gray-900">{CONTACT_INFO.qq}</span>
                <button 
                  onClick={() => copyToClipboard(CONTACT_INFO.qq)}
                  className="p-1.5 text-gray-500 hover:text-emerald-500 hover:bg-emerald-50 rounded-lg transition-colors"
                >
                  {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer Info */}
        <section className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Check className="w-5 h-5 text-cyan-300" />
            <h3 className="text-white font-medium">品质开荒 · 明码实价</h3>
          </div>
          <p className="text-white/70 text-sm leading-relaxed">
            看图下单，需要哪个套餐直接购买相应金额，备注客户端当前赛季即可
          </p>
        </section>
      </main>

      {/* Payment Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-emerald-500" />
              扫码支付
            </DialogTitle>
            <DialogDescription className="text-gray-500">
              请选择支付方式并扫描二维码
            </DialogDescription>
          </DialogHeader>
          {selectedService && (
            <div className="space-y-4">
              {/* Service Info */}
              <div className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-xl p-4 border border-rose-100">
                <p className="font-medium text-gray-900">{selectedService.name}</p>
                <p className="text-2xl font-bold text-rose-500 mt-1">
                  ¥{selectedService.price}
                </p>
              </div>

              {/* Payment Method Tabs */}
              <div className="flex gap-2">
                <button
                  onClick={() => setPaymentMethod('wechat')}
                  className={`flex-1 py-2.5 px-4 rounded-xl font-medium text-sm transition-all ${
                    paymentMethod === 'wechat'
                      ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  微信支付
                </button>
                <button
                  onClick={() => setPaymentMethod('alipay')}
                  className={`flex-1 py-2.5 px-4 rounded-xl font-medium text-sm transition-all ${
                    paymentMethod === 'alipay'
                      ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  支付宝
                </button>
              </div>

              {/* QR Code */}
              <div className="flex flex-col items-center">
                <div className={`rounded-2xl p-4 border-2 ${
                  paymentMethod === 'wechat' 
                    ? 'bg-emerald-50 border-emerald-200' 
                    : 'bg-blue-50 border-blue-200'
                }`}>
                  <img 
                    src={paymentMethod === 'wechat' ? '/wechat-pay.png' : '/alipay.jpg'}
                    alt={paymentMethod === 'wechat' ? '微信支付收款码' : '支付宝收款码'}
                    className="w-56 h-auto rounded-xl"
                  />
                </div>
                <p className={`text-sm mt-3 flex items-center gap-1 ${
                  paymentMethod === 'wechat' ? 'text-emerald-600' : 'text-blue-600'
                }`}>
                  <QrCode className="w-4 h-4" />
                  请使用{paymentMethod === 'wechat' ? '微信' : '支付宝'}扫一扫付款
                </p>
              </div>

              {/* Payment Steps */}
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <span className={`w-5 h-5 text-white text-xs rounded-full flex items-center justify-center flex-shrink-0 ${
                    paymentMethod === 'wechat' ? 'bg-emerald-500' : 'bg-blue-500'
                  }`}>1</span>
                  <div>
                    <p className="font-medium text-gray-900">截图保存收款码</p>
                    <p className="text-gray-500">长按图片保存到相册</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <span className={`w-5 h-5 text-white text-xs rounded-full flex items-center justify-center flex-shrink-0 ${
                    paymentMethod === 'wechat' ? 'bg-emerald-500' : 'bg-blue-500'
                  }`}>2</span>
                  <div>
                    <p className="font-medium text-gray-900">打开{paymentMethod === 'wechat' ? '微信' : '支付宝'}扫一扫</p>
                    <p className="text-gray-500">从相册选择收款码图片</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <span className={`w-5 h-5 text-white text-xs rounded-full flex items-center justify-center flex-shrink-0 ${
                    paymentMethod === 'wechat' ? 'bg-emerald-500' : 'bg-blue-500'
                  }`}>3</span>
                  <div>
                    <p className="font-medium text-gray-900">输入金额并付款</p>
                    <p className="text-gray-500">金额：¥{selectedService.price}，备注服务名称</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <span className={`w-5 h-5 text-white text-xs rounded-full flex items-center justify-center flex-shrink-0 ${
                    paymentMethod === 'wechat' ? 'bg-emerald-500' : 'bg-blue-500'
                  }`}>4</span>
                  <div>
                    <p className="font-medium text-gray-900">联系客服确认</p>
                    <p className="text-gray-500">加微信 {CONTACT_INFO.wechat} 发送付款截图</p>
                  </div>
                </div>
              </div>

              {/* Contact Button */}
              <Button 
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                onClick={() => {
                  copyToClipboard(CONTACT_INFO.wechat);
                  window.location.href = `weixin://`;
                }}
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                添加客服微信
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
